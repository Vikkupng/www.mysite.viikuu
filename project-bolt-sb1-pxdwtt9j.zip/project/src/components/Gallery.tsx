import React from 'react';
import { Camera, Users, Award, Presentation, Code, Shield } from 'lucide-react';

const Gallery = () => {
  const galleryItems = [
    {
      id: 1,
      title: 'Cybersecurity Workshop',
      description: 'Leading a hands-on cybersecurity workshop for professionals',
      image: 'https://images.pexels.com/photos/5380792/pexels-photo-5380792.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      category: 'Teaching',
      icon: Presentation
    },
    {
      id: 2,
      title: 'Security Conference',
      description: 'Speaking at the Annual Cybersecurity Summit 2024',
      image: 'https://images.pexels.com/photos/2608517/pexels-photo-2608517.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      category: 'Speaking',
      icon: Users
    },
    {
      id: 3,
      title: 'Certification Achievement',
      description: 'Receiving advanced cybersecurity certification',
      image: 'https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      category: 'Achievement',
      icon: Award
    },
    {
      id: 4,
      title: 'Penetration Testing Lab',
      description: 'Demonstrating ethical hacking techniques in controlled environment',
      image: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      category: 'Lab Work',
      icon: Code
    },
    {
      id: 5,
      title: 'Security Audit Session',
      description: 'Conducting comprehensive security assessment for enterprise client',
      image: 'https://images.pexels.com/photos/5483077/pexels-photo-5483077.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      category: 'Consulting',
      icon: Shield
    },
    {
      id: 6,
      title: 'Team Training Session',
      description: 'Training corporate teams on cybersecurity best practices',
      image: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      category: 'Training',
      icon: Users
    }
  ];

  const categories = ['All', 'Teaching', 'Speaking', 'Achievement', 'Lab Work', 'Consulting', 'Training'];
  const [selectedCategory, setSelectedCategory] = React.useState('All');

  const filteredItems = selectedCategory === 'All' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === selectedCategory);

  return (
    <section id="gallery" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
            Gallery
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-orange-500 mx-auto mb-8"></div>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            A glimpse into my professional journey, achievements, and the impact of cybersecurity education.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg'
                  : 'bg-gray-100 text-slate-600 hover:bg-gray-200'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <div key={item.id} className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300">
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <div className="flex items-center mb-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center mr-3">
                      <item.icon className="h-5 w-5" />
                    </div>
                    <span className="text-sm font-semibold text-blue-300">{item.category}</span>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-gray-300 text-sm leading-relaxed">{item.description}</p>
                </div>
              </div>

              {/* Category Badge */}
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-slate-800 text-sm font-semibold rounded-full">
                  {item.category}
                </span>
              </div>
            </div>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <Camera className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <p className="text-xl text-gray-500">No items found in this category.</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default Gallery;