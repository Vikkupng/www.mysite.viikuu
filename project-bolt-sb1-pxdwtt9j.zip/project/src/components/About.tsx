import React from 'react';
import { Shield, Target, Users, Award } from 'lucide-react';

const About = () => {
  const skills = [
    { icon: Shield, title: 'Threat Analysis', description: 'Advanced threat detection and analysis techniques' },
    { icon: Target, title: 'Vulnerability Assessment', description: 'Comprehensive security vulnerability evaluation' },
    { icon: Users, title: 'Incident Response', description: 'Rapid response to security incidents and breaches' },
    { icon: Award, title: 'Digital Asset Protection', description: 'Safeguarding sensitive information and systems' }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
            About Me
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-orange-500 mx-auto mb-8"></div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <div className="bg-gradient-to-br from-slate-100 to-blue-50 rounded-2xl p-8 shadow-lg">
              <h3 className="text-2xl font-bold text-slate-900 mb-6">My Journey</h3>
              <p className="text-lg text-slate-700 leading-relaxed mb-6">
                As a dedicated cybersecurity enthusiast, I specialize in protecting digital assets from emerging threats. 
                With expertise in threat analysis, vulnerability assessment, and incident response, I help individuals 
                and organizations safeguard their sensitive information.
              </p>
              <p className="text-lg text-slate-700 leading-relaxed">
                My passion lies in staying ahead of cyber threats and ensuring the security and integrity of digital systems. 
                I believe in continuous learning and sharing knowledge to build a more secure digital world.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {skills.map((skill, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-blue-200">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mb-4">
                  <skill.icon className="h-6 w-6 text-white" />
                </div>
                <h4 className="text-xl font-bold text-slate-900 mb-2">{skill.title}</h4>
                <p className="text-slate-600">{skill.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-r from-slate-900 to-blue-900 rounded-2xl p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">Ready to Secure Your Digital Future?</h3>
          <p className="text-xl text-gray-300 mb-6">
            Let's work together to protect what matters most to you.
          </p>
          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg font-semibold hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            Start the Conversation
          </button>
        </div>
      </div>
    </section>
  );
};

export default About;