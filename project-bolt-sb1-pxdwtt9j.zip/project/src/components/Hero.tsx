import React from 'react';
import { ChevronDown, Shield, Lock, Search } from 'lucide-react';

const Hero = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 flex items-center justify-center relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 border-2 border-blue-500 rounded-full animate-pulse"></div>
        <div className="absolute top-1/3 right-20 w-16 h-16 border-2 border-orange-500 rounded-lg rotate-45 animate-bounce"></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 border-2 border-blue-400 rounded-full animate-pulse delay-500"></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="mb-8 flex justify-center space-x-4">
          <div className="p-3 bg-blue-500/20 rounded-full backdrop-blur-sm">
            <Shield className="h-8 w-8 text-blue-400" />
          </div>
          <div className="p-3 bg-orange-500/20 rounded-full backdrop-blur-sm">
            <Lock className="h-8 w-8 text-orange-400" />
          </div>
          <div className="p-3 bg-blue-500/20 rounded-full backdrop-blur-sm">
            <Search className="h-8 w-8 text-blue-400" />
          </div>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
          <span className="bg-gradient-to-r from-blue-400 to-orange-400 bg-clip-text text-transparent">
            Vikash Vidyanshu
          </span>
        </h1>
        
        <p className="text-xl md:text-2xl text-gray-300 mb-8 font-light">
          Cyber Security Engineer
        </p>
        
        <p className="text-lg text-gray-400 mb-12 max-w-2xl mx-auto leading-relaxed">
          Protecting digital assets from emerging threats with expertise in threat analysis, 
          vulnerability assessment, and incident response.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button
            onClick={() => scrollToSection('about')}
            className="px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            Learn More About Me
          </button>
          <button
            onClick={() => scrollToSection('contact')}
            className="px-8 py-4 border-2 border-orange-500 text-orange-400 rounded-lg font-semibold hover:bg-orange-500 hover:text-white transition-all duration-300"
          >
            Get In Touch
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <button
          onClick={() => scrollToSection('about')}
          className="text-gray-400 hover:text-white transition-colors duration-300"
        >
          <ChevronDown className="h-8 w-8" />
        </button>
      </div>
    </section>
  );
};

export default Hero;