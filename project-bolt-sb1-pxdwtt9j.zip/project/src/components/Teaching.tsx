import React from 'react';
import { BookOpen, Users, Award, Clock, CheckCircle } from 'lucide-react';

const Teaching = () => {
  const courses = [
    {
      title: 'Cybersecurity Fundamentals',
      description: 'Learn the basics of cybersecurity, threat landscape, and protection strategies.',
      duration: '8 weeks',
      level: 'Beginner',
      topics: ['Network Security', 'Risk Assessment', 'Security Policies', 'Incident Response Basics']
    },
    {
      title: 'Advanced Threat Analysis',
      description: 'Deep dive into threat hunting, malware analysis, and forensic techniques.',
      duration: '12 weeks',
      level: 'Advanced',
      topics: ['Malware Analysis', 'Digital Forensics', 'Threat Intelligence', 'Advanced Persistent Threats']
    },
    {
      title: 'Vulnerability Assessment',
      description: 'Master the art of finding and assessing security vulnerabilities.',
      duration: '10 weeks',
      level: 'Intermediate',
      topics: ['Penetration Testing', 'Vulnerability Scanning', 'Risk Evaluation', 'Remediation Strategies']
    }
  ];

  const features = [
    { icon: Users, title: 'Hands-on Learning', description: 'Interactive sessions with real-world scenarios' },
    { icon: Award, title: 'Industry Recognition', description: 'Certificates recognized by leading organizations' },
    { icon: BookOpen, title: 'Comprehensive Materials', description: 'Updated curriculum with latest threats and tools' },
    { icon: Clock, title: 'Flexible Schedule', description: 'Evening and weekend sessions available' }
  ];

  return (
    <section id="teaching" className="py-20 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
            Teaching & Training
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-orange-500 mx-auto mb-8"></div>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Empowering the next generation of cybersecurity professionals through comprehensive 
            training programs and hands-on learning experiences.
          </p>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {features.map((feature, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <feature.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">{feature.title}</h3>
              <p className="text-slate-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Courses */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {courses.map((course, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                  course.level === 'Beginner' ? 'bg-green-100 text-green-800' :
                  course.level === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {course.level}
                </span>
                <span className="text-slate-500 text-sm font-medium">{course.duration}</span>
              </div>
              
              <h3 className="text-2xl font-bold text-slate-900 mb-4">{course.title}</h3>
              <p className="text-slate-600 mb-6 leading-relaxed">{course.description}</p>
              
              <div className="mb-6">
                <h4 className="text-lg font-semibold text-slate-900 mb-3">What You'll Learn:</h4>
                <ul className="space-y-2">
                  {course.topics.map((topic, topicIndex) => (
                    <li key={topicIndex} className="flex items-center text-slate-600">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      {topic}
                    </li>
                  ))}
                </ul>
              </div>
              
              <button className="w-full py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-300">
                Learn More
              </button>
            </div>
          ))}
        </div>

        <div className="text-center">
          <h3 className="text-2xl font-bold text-slate-900 mb-4">Ready to Start Learning?</h3>
          <p className="text-lg text-slate-600 mb-8">
            Join thousands of students who have advanced their cybersecurity careers with our programs.
          </p>
          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg font-semibold hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            Enroll Today
          </button>
        </div>
      </div>
    </section>
  );
};

export default Teaching;